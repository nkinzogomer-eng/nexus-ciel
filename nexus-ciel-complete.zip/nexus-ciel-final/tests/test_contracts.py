import pytest
from nexus.schemas import Mission, Capability, MissionState, Verdict
from nexus.core.state import assert_transition, IllegalTransition
from nexus.guard import MissionGuard, GuardLimits
from nexus.capabilities import CapabilityEngine

def test_mission_contract_and_state_graph():
    m=Mission(objective="x")
    assert all(hasattr(m,x) for x in ["mission_id","objective","priority","quality_floor","status","plan","scratchpad_id","created_at","updated_at"])
    assert_transition(MissionState.accepted,MissionState.planning)
    with pytest.raises(IllegalTransition): assert_transition(MissionState.done,MissionState.running)

def test_guard_limits():
    g=MissionGuard(GuardLimits(max_iterations=1)); assert g.check(2,0).should_abort

def test_capability_all_kinds():
    e=CapabilityEngine(); c=Capability(name="x",kind="workflow",definition={}); assert e.promote(e.approve_for_probation(c,True,True),10).status=="promoted"
