# Nexus Ciel

Phase 0 à fondations des phases 1-7, usage interne d'abord. Les contrats sont posés sans prétendre que les phases avancées sont déjà opérationnelles: Router, channels, capabilities et fabric sont des ports testables; la CI protège chaque ajout.

```bash
python -m venv .venv && source .venv/bin/activate
pip install -e '.[dev]'
pytest -q
```

La suite complète nécessite PostgreSQL, Redis et Ollama selon la configuration de déploiement. Ne jamais promouvoir une capacité sans oracle, revue, sandbox et probation.
