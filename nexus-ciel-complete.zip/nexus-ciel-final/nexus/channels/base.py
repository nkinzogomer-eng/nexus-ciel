from __future__ import annotations
from typing import Protocol
from pydantic import BaseModel
class InboundMessage(BaseModel): channel:str; sender_id:str; text:str
class OutboundMessage(BaseModel): channel:str; recipient_id:str; text:str
class ChannelAdapter(Protocol):
    name:str
    async def send(self,msg:OutboundMessage)->None: ...
