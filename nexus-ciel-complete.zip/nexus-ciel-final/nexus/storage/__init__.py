class InMemoryRepository:
    def __init__(self): self.events=[]; self.missions={}; self.reports={}; self.scratch=[]
    async def save_mission(self,m): self.missions[m.mission_id]=m
    async def set_state(self,i,s): self.missions[i].status=s
    async def append_event(self,e): self.events.append(e)
    async def append_scratch(self,e): self.scratch.append(e)
    async def save_report(self,r): self.reports[r.mission_id]=r
