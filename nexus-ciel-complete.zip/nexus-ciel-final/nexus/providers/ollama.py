import httpx
from .base import CompletionRequest, CompletionResult
class OllamaAdapter:
    name="ollama"
    def __init__(self, base_url:str, model:str): self.base_url=base_url.rstrip('/'); self.model=model
    async def complete(self, req:CompletionRequest)->CompletionResult:
        async with httpx.AsyncClient(timeout=120) as c:
            r=await c.post(f"{self.base_url}/api/generate",json={"model":self.model,"prompt":req.prompt,"stream":False}); r.raise_for_status(); d=r.json()
        return CompletionResult(text=d.get("response",""),provider=self.name)
    async def health(self)->bool:
        try:
            async with httpx.AsyncClient(timeout=5) as c: return (await c.get(f"{self.base_url}/api/tags")).status_code==200
        except Exception:return False
