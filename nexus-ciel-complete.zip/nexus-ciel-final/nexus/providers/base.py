from typing import Protocol
from pydantic import BaseModel
class CompletionRequest(BaseModel): prompt:str; max_tokens:int=512
class CompletionResult(BaseModel): text:str; cost_usd:float=0.0; provider:str
class ProviderAdapter(Protocol):
    name:str
    async def complete(self, req:CompletionRequest)->CompletionResult: ...
    async def health(self)->bool: ...
