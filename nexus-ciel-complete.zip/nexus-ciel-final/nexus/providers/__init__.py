from .base import *
from .ollama import OllamaAdapter
