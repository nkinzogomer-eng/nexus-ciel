from __future__ import annotations
import time
from pydantic import BaseModel
class GuardLimits(BaseModel):
    max_iterations:int=25; max_cost_usd:float=5.0; timeout_seconds:int=900; max_tool_calls:int=100
class GuardDecision(BaseModel): should_abort:bool; abort_reason:str|None=None
class MissionGuard:
    def __init__(self, limits:GuardLimits): self.limits=limits; self.started=time.monotonic()
    def check(self, iterations:int, cost_usd:float, tool_calls:int=0)->GuardDecision:
        checks=((iterations>self.limits.max_iterations,f"max_iterations: {iterations}"),(cost_usd>self.limits.max_cost_usd,f"max_cost_usd: {cost_usd}"),(tool_calls>self.limits.max_tool_calls,f"max_tool_calls: {tool_calls}"),(time.monotonic()-self.started>self.limits.timeout_seconds,"timeout"))
        for hit,reason in checks:
            if hit:return GuardDecision(should_abort=True,abort_reason=reason)
        return GuardDecision(should_abort=False)
