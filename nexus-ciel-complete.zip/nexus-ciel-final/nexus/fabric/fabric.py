from dataclasses import dataclass
@dataclass
class ExecutionLimits: timeout_s:int=120; memory_mb:int=1024; max_retries:int=2; network:bool=False
class ExecutionFabric:
    def __init__(self, limits:ExecutionLimits|None=None): self.limits=limits or ExecutionLimits()
    def isolation_level(self, trusted:bool=False)->str: return "in-process" if trusted else "container-no-network"
