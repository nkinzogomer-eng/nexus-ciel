from __future__ import annotations
from nexus.providers.base import ProviderAdapter, CompletionRequest, CompletionResult
class AdaptiveRouter:
    """Cascade providerielle. Phase 0 accepte un provider; phases suivantes en ajoutent."""
    def __init__(self, providers:list[ProviderAdapter]): self.providers=providers
    async def complete(self, req:CompletionRequest)->CompletionResult:
        errors=[]
        for provider in self.providers:
            if not await provider.health(): continue
            try:return await provider.complete(req)
            except Exception as exc: errors.append(f"{provider.name}: {exc}")
        raise RuntimeError("no provider available: " + "; ".join(errors))
