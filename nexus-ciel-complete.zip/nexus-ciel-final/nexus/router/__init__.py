from .router import AdaptiveRouter
