from __future__ import annotations
from nexus.schemas import Capability
class CapabilityEngine:
    """Oracle -> review -> sandbox/probation -> promotion, pour tous les kinds."""
    def propose(self, cap:Capability)->Capability: cap.status="proposed"; return cap
    def approve_for_probation(self, cap:Capability, oracle_passed:bool, review_passed:bool)->Capability:
        if oracle_passed and review_passed: cap.status="probation"
        else: cap.status="rejected"
        return cap
    def promote(self, cap:Capability, successes:int, minimum:int=10)->Capability:
        if cap.status=="probation" and successes>=minimum: cap.status="promoted"
        return cap
