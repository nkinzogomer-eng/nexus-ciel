from dataclasses import dataclass, field
from enum import Enum
from typing import Any
from uuid import UUID, uuid4
import time
class State(str,Enum): ACCEPTED='accepted'; PLANNING='planning'; RUNNING='running'; DONE='done'; FAILED='failed'; ABORTED='aborted'
class Verdict(str,Enum): PASS='PASS'; FAIL='FAIL'; PARTIAL='PARTIAL'
@dataclass
class Mission:
    objective:str; mission_id:UUID=field(default_factory=uuid4); priority:str='normal'; budget:float=5.0; max_iterations:int=25; status:State=State.ACCEPTED; plan:list[str]=field(default_factory=list); scratchpad:list[str]=field(default_factory=list); created_at:float=field(default_factory=time.time); updated_at:float=field(default_factory=time.time)
@dataclass
class Event:
    type:str; mission_id:UUID|None=None; payload:dict[str,Any]=field(default_factory=dict); id:UUID=field(default_factory=uuid4); timestamp:float=field(default_factory=time.time)
@dataclass
class Report:
    mission_id:UUID; verdict:Verdict; summary:str; iterations:int; cost:float; duration:float; abort_reason:str|None=None
@dataclass
class Capability:
    name:str; kind:str; definition:dict[str,Any]; id:UUID=field(default_factory=uuid4); status:str='proposed'; evidence:list[str]=field(default_factory=list); version:int=1
