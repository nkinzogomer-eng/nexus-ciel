class Evolution:
 def prove_promotion(self,baseline,candidate,cases,min_delta=.05):
  b=sum(fn(x) for x,fn in cases if fn is baseline)/len(cases) if cases else 0
  c=sum(fn(x) for x,fn in cases if fn is candidate)/len(cases) if cases else 0
  return {'baseline':b,'candidate':c,'promote':c-b>=min_delta}
