from collections import defaultdict
class EventBus:
 def __init__(self): self.events=[]; self.handlers=defaultdict(list)
 def subscribe(self,typ,handler): self.handlers[typ].append(handler)
 def publish(self,event):
  self.events.append(event)
  for h in self.handlers[event.type]: h(event)
