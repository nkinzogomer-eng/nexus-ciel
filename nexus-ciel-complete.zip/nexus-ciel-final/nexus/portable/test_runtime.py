import unittest
from nexus.portable.models import Mission,Verdict
from nexus.portable.providers import EchoProvider,FailingProvider
from nexus.portable.router import AdaptiveRouter
from nexus.portable.runtime import Runtime
from nexus.portable.capabilities import CapabilityEngine
from nexus.portable.gym import Gymnasium,Case
from nexus.portable.fabric import Fabric
class T(unittest.TestCase):
 def test_pass_and_events(self):
  rt=Runtime(AdaptiveRouter([EchoProvider()])); r=rt.run(Mission('hello')); self.assertEqual(r.verdict,Verdict.PASS); self.assertEqual(rt.store.db.execute('SELECT COUNT(*) FROM events').fetchone()[0],6)
 def test_failover_failure(self): self.assertEqual(Runtime(AdaptiveRouter([FailingProvider()])).run(Mission('x')).verdict,Verdict.FAIL)
 def test_capability(self):
  e=CapabilityEngine(); c=e.propose('p','policy',{}); e.review(c,True,True); self.assertEqual(e.promote(c,10).status,'promoted')
 def test_gym(self): self.assertEqual(Gymnasium().replay(lambda x:x.upper(),[Case('a','A')])['rate'],1)
 def test_fabric_timeout(self): self.assertFalse(Fabric().run_python('while True: pass',1)['ok'])
if __name__=='__main__': unittest.main()
