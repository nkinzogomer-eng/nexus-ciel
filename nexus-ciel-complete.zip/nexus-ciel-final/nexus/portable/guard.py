import time
class Guard:
 def __init__(self,max_iterations=25,max_cost=5.0,timeout=900): self.max_iterations=max_iterations; self.max_cost=max_cost; self.timeout=timeout; self.started=time.monotonic()
 def check(self,iterations,cost):
  if iterations>self.max_iterations:return 'max_iterations'
  if cost>self.max_cost:return 'max_cost'
  if time.monotonic()-self.started>self.timeout:return 'timeout'
  return None
