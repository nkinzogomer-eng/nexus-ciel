import subprocess,sys
class Fabric:
 def run_python(self,code,timeout=5):
  try:
   p=subprocess.run([sys.executable,'-I','-c',code],capture_output=True,text=True,timeout=timeout)
   return {'ok':p.returncode==0,'stdout':p.stdout,'stderr':p.stderr,'returncode':p.returncode}
  except subprocess.TimeoutExpired:return {'ok':False,'stdout':'','stderr':'timeout','returncode':-1}
