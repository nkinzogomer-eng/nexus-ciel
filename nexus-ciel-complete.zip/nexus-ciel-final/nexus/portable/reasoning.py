class FormalReasoning:
 def all(self,conditions): return all(conditions)
 def any(self,conditions): return any(conditions)
 def require(self,condition,message):
  if not condition: raise ValueError(message)
  return True
class GreatSage:
 def advise(self,question,evidence): return {'question':question,'evidence':evidence,'recommendation':'review_required'}
