class Memory:
 def __init__(self,store): self.store=store
 def consolidate(self,mission_id,text,tags=()): self.store.add_memory(text,{'mission_id':str(mission_id),'tags':list(tags)})
 def recall(self,term): return self.store.search_memory(term)
