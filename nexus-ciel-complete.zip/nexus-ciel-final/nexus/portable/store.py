import sqlite3, json
from .models import Event, Mission, Report
class Store:
 def __init__(self,path=':memory:'):
  self.db=sqlite3.connect(path); self.db.executescript('CREATE TABLE IF NOT EXISTS missions(id TEXT PRIMARY KEY,payload TEXT); CREATE TABLE IF NOT EXISTS events(id TEXT PRIMARY KEY,type TEXT,mission TEXT,payload TEXT); CREATE TABLE IF NOT EXISTS reports(id TEXT PRIMARY KEY,payload TEXT); CREATE TABLE IF NOT EXISTS memory(id TEXT PRIMARY KEY,text TEXT,metadata TEXT);')
 def mission(self,m): self.db.execute('INSERT OR REPLACE INTO missions VALUES(?,?)',(str(m.mission_id),json.dumps(m,default=lambda x:x.value if hasattr(x,'value') else str(x)))); self.db.commit()
 def event(self,e): self.db.execute('INSERT INTO events VALUES(?,?,?,?)',(str(e.id),e.type,str(e.mission_id),json.dumps(e.payload))); self.db.commit()
 def report(self,r): self.db.execute('INSERT OR REPLACE INTO reports VALUES(?,?)',(str(r.mission_id),json.dumps(r,default=lambda x:x.value if hasattr(x,'value') else str(x)))); self.db.commit()
 def add_memory(self,text,metadata):
  import uuid; self.db.execute('INSERT INTO memory VALUES(?,?,?)',(str(uuid.uuid4()),text,json.dumps(metadata))); self.db.commit()
 def search_memory(self,term): return self.db.execute('SELECT text,metadata FROM memory WHERE text LIKE ?',('%'+term+'%',)).fetchall()
