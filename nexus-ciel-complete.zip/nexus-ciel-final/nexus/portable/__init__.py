"""Reference runtime stdlib-only: executable offline core for phases 1-7."""
