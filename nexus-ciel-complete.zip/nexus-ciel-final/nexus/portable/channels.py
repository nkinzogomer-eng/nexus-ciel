from dataclasses import dataclass
@dataclass
class Message: channel:str; sender:str; text:str
class MemoryChannel:
 def __init__(self): self.sent=[]
 def send(self,text,recipient='local'): self.sent.append(Message('local',recipient,text))
