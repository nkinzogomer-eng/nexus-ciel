import time
from .models import Mission,State,Verdict,Report,Event
from .bus import EventBus
from .store import Store
from .router import AdaptiveRouter
from .guard import Guard
class Runtime:
 def __init__(self,router,store=None,bus=None): self.router=router; self.store=store or Store(); self.bus=bus or EventBus()
 def emit(self,typ,m,**payload):
  e=Event(typ,m.mission_id,payload); self.store.event(e); self.bus.publish(e)
 def run(self,m):
  start=time.monotonic(); self.store.mission(m); self.emit('MissionAccepted',m)
  m.status=State.PLANNING; self.emit('MissionStateChanged',m,to=m.status.value); m.plan=['route','execute','validate']; self.emit('MissionPlanned',m)
  reason=Guard(m.max_iterations,m.budget).check(1,0)
  if reason: m.status=State.ABORTED; r=Report(m.mission_id,Verdict.FAIL,'aborted',1,0,time.monotonic()-start,reason); self.store.report(r); return r
  m.status=State.RUNNING; self.emit('MissionStateChanged',m,to=m.status.value)
  try: result=self.router.complete(m.objective); text=result.text.strip(); verdict=Verdict.PASS if text else Verdict.PARTIAL; summary=text
  except Exception as e: verdict=Verdict.FAIL; summary=str(e)
  m.status=State.DONE if verdict!=Verdict.FAIL else State.FAILED; self.emit('MissionStateChanged',m,to=m.status.value); r=Report(m.mission_id,verdict,summary,1,0,time.monotonic()-start); self.store.report(r); self.emit('MissionValidated',m,verdict=verdict.value); return r
