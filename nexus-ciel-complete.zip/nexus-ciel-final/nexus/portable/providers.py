from dataclasses import dataclass
@dataclass
class Result: text:str; provider:str; cost:float=0.0
class Provider:
 name='base'
 def health(self): return True
 def complete(self,prompt): raise NotImplementedError
class EchoProvider(Provider):
 name='echo'
 def complete(self,prompt): return Result('Echo: '+prompt,self.name)
class FailingProvider(Provider):
 name='failing'
 def health(self): return False
 def complete(self,prompt): raise RuntimeError('unavailable')
