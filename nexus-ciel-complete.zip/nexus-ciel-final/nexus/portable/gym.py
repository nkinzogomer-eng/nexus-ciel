from dataclasses import dataclass
@dataclass
class Case: input:str; expected:str
class Gymnasium:
 def replay(self,fn,cases):
  results=[]
  for c in cases:
   try: out=fn(c.input); results.append(out==c.expected)
   except Exception: results.append(False)
  return {'runs':len(results),'successes':sum(results),'rate':sum(results)/len(results) if results else 0.0}
