from .providers import Result
class AdaptiveRouter:
 def __init__(self,providers): self.providers=providers; self.trace=[]
 def complete(self,prompt):
  errors=[]
  for p in self.providers:
   if not p.health(): self.trace.append((p.name,'unhealthy')); continue
   try:
    r=p.complete(prompt); self.trace.append((p.name,'selected')); return r
   except Exception as e: errors.append(str(e)); self.trace.append((p.name,'failed'))
  raise RuntimeError('no provider available: '+';'.join(errors))
