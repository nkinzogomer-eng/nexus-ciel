from .models import Capability
class CapabilityEngine:
 KINDS={'workflow','policy','pipeline','strategy','tool_combo','prompt','orchestration','rule','code'}
 def propose(self,name,kind,definition):
  if kind not in self.KINDS: raise ValueError('unknown capability kind')
  return Capability(name,kind,definition)
 def review(self,c,oracle_ok,review_ok): c.status='probation' if oracle_ok and review_ok else 'rejected'; c.evidence+=['oracle','review'] if oracle_ok and review_ok else ['rejected']; return c
 def promote(self,c,successes,min_success=10):
  if c.status=='probation' and successes>=min_success:c.status='promoted'; c.evidence.append(f'{successes}_real_successes')
  return c
