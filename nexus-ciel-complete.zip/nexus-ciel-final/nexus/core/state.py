from nexus.schemas import MissionState
class IllegalTransition(Exception): pass
ALLOWED = {
 MissionState.accepted:{MissionState.planning,MissionState.aborted},
 MissionState.planning:{MissionState.running,MissionState.failed,MissionState.aborted},
 MissionState.running:{MissionState.done,MissionState.failed,MissionState.aborted},
 MissionState.done:set(), MissionState.failed:set(), MissionState.aborted:set(),
}
def assert_transition(src: MissionState, dst: MissionState) -> None:
    if dst not in ALLOWED[src]: raise IllegalTransition(f"{src.value} -> {dst.value}")
