from __future__ import annotations
import time
from uuid import uuid4
from nexus.schemas import Mission, Report, Event, Verdict, MissionState, ScratchpadEntry
from nexus.providers.base import ProviderAdapter, CompletionRequest
from nexus.bus.base import EventBus
from nexus.guard import MissionGuard, GuardLimits
from .state import assert_transition
class Manas:
    def __init__(self, provider:ProviderAdapter, bus:EventBus, repo, limits:GuardLimits|None=None): self.provider=provider; self.bus=bus; self.repo=repo; self.limits=limits or GuardLimits()
    async def emit(self, typ:str, mission:Mission, **payload):
        e=Event(type=typ,mission_id=mission.mission_id,payload=payload); await self.repo.append_event(e); await self.bus.publish(e)
    async def transition(self,m:Mission,dst:MissionState):
        assert_transition(m.status,dst); old=m.status; m.status=dst; await self.repo.set_state(m.mission_id,dst); await self.emit("MissionStateChanged",m,from_=old.value,to=dst.value)
    async def run(self,m:Mission)->Report:
        start=time.monotonic(); guard=MissionGuard(self.limits); m.scratchpad_id=uuid4(); await self.repo.save_mission(m); await self.emit("MissionAccepted",m)
        await self.transition(m,MissionState.planning); await self.repo.append_scratch(ScratchpadEntry(mission_id=m.mission_id,seq=0,note=m.objective)); await self.emit("MissionPlanned",m)
        d=guard.check(1,0)
        if d.should_abort: await self.transition(m,MissionState.aborted); r=Report(mission_id=m.mission_id,verdict=Verdict.FAIL,objective=m.objective,summary="aborted",iterations=1,duration_s=time.monotonic()-start,abort_reason=d.abort_reason); await self.repo.save_report(r); return r
        await self.transition(m,MissionState.running)
        try:
            x=await self.provider.complete(CompletionRequest(prompt=m.objective)); text=x.text.strip(); verdict=Verdict.PASS if text else Verdict.PARTIAL; summary=text or "(empty)"
        except Exception as exc: verdict=Verdict.FAIL; summary=f"provider failure: {exc}"
        await self.transition(m,MissionState.done if verdict!=Verdict.FAIL else MissionState.failed); r=Report(mission_id=m.mission_id,verdict=verdict,objective=m.objective,summary=summary,iterations=1,duration_s=time.monotonic()-start); await self.repo.save_report(r); await self.emit("MissionValidated",m,verdict=verdict.value); return r
