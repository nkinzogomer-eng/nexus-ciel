from __future__ import annotations
import asyncio
from collections import defaultdict
from nexus.schemas import Event
from .base import Handler
class AsyncEventBus:
    def __init__(self): self._subs: dict[str,list[Handler]] = defaultdict(list)
    async def publish(self, event: Event) -> None:
        await asyncio.gather(*(h(event) for h in self._subs.get(event.type, [])))
    async def subscribe(self, event_type: str, handler: Handler) -> None: self._subs[event_type].append(handler)
