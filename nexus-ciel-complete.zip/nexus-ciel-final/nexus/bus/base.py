from __future__ import annotations
from typing import Awaitable, Callable, Protocol
from nexus.schemas import Event
Handler = Callable[[Event], Awaitable[None]]
class EventBus(Protocol):
    async def publish(self, event: Event) -> None: ...
    async def subscribe(self, event_type: str, handler: Handler) -> None: ...
