from __future__ import annotations
from datetime import datetime, timezone
from enum import Enum
from typing import Any, Literal
from uuid import UUID, uuid4
from pydantic import BaseModel, Field


def now() -> datetime: return datetime.now(timezone.utc)

class MissionState(str, Enum):
    accepted="accepted"; planning="planning"; running="running"; done="done"; failed="failed"; aborted="aborted"
class Verdict(str, Enum): PASS="PASS"; FAIL="FAIL"; PARTIAL="PARTIAL"
class QualityFloor(str, Enum): none="none"; basic="basic"; high="high"

class Constraints(BaseModel):
    deadline: datetime | None = None
    budget_usd: float = 5.0
    forbidden: list[str] = Field(default_factory=list)

class Mission(BaseModel):
    schema_version: int = 1
    mission_id: UUID = Field(default_factory=uuid4)
    objective: str
    priority: str = "normal"
    quality_floor: QualityFloor = QualityFloor.basic
    constraints: Constraints = Field(default_factory=Constraints)
    status: MissionState = MissionState.accepted
    plan: list[str] = Field(default_factory=list)
    scratchpad_id: UUID | None = None
    created_by: str = "human"
    created_at: datetime = Field(default_factory=now)
    updated_at: datetime = Field(default_factory=now)

class Event(BaseModel):
    id: UUID = Field(default_factory=uuid4)
    type: str
    schema_version: int = 1
    mission_id: UUID | None = None
    timestamp: datetime = Field(default_factory=now)
    payload: dict[str, Any] = Field(default_factory=dict)
    causation_id: UUID | None = None
    correlation_id: UUID | None = None

class Report(BaseModel):
    schema_version: int = 1
    mission_id: UUID
    verdict: Verdict
    objective: str
    summary: str
    iterations: int
    cost_usd: float = 0.0
    duration_s: float
    abort_reason: str | None = None

class Capability(BaseModel):
    schema_version: int = 1
    capability_id: UUID = Field(default_factory=uuid4)
    name: str
    kind: Literal["workflow","policy","pipeline","strategy","tool_combo","prompt","orchestration","rule","code"]
    version: int = 1
    definition: dict[str, Any] = Field(default_factory=dict)
    status: Literal["proposed","probation","promoted","rejected"] = "proposed"
    evidence: list[str] = Field(default_factory=list)

class ScratchpadEntry(BaseModel):
    id: UUID = Field(default_factory=uuid4)
    mission_id: UUID
    seq: int
    note: str
    created_at: datetime = Field(default_factory=now)
