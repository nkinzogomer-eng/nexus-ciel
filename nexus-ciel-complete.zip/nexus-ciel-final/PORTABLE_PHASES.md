# Portable implementation status

This stdlib-only runtime is executable offline and covers the functional reference path for phases 1-7: routing/failover, event persistence, memory consolidation/recall, formal reasoning and Great Sage advice, capability lifecycle for all nine kinds, subprocess fabric timeout, gym replay/evolution proof, and channel message output.

External production adapters remain separately required: FastAPI, PostgreSQL/pgvector, Redis Streams, Telegram API, Docker network isolation, Ollama/remote LLMs, and OpenTelemetry. They cannot be honestly claimed tested without their dependencies and services.
