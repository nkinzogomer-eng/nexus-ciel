# Plan de livraison

- Phase 0: contrats Mission/Event/Report, Manas OODA, State Graph, Guard, repository de test. PASS = tests verts.
- Phase 1: Adaptive Router réel et cache Redis. Garder ProviderAdapter inchangé.
- Phase 2: PostgreSQL/Alembic + Redis Streams, migrations testées.
- Phase 3: Fabric conteneurisé, timeouts, kill-switch, budgets durs.
- Phase 4: mémoire consolidée et pgvector, distincte du Scratchpad.
- Phase 5: Capability Creation pour les 9 kinds, oracle/review/probation/promotion.
- Phase 6: canaux ClickUp/Telegram avec authentification et human-in-the-loop.
- Phase 7: Gymnase/Evolution/Great Sage. Chaque phase doit finir par un scénario PASS rejouable.
